// tools/lab/labSim.ts — laboratorio de partidas Buddha contra Buddha.
// 15 nov 2026. NO forma parte del juego (vive fuera de src/): usa el
// reducer real y el bot real, y mide qué pasa en partidas completas.
//
// Uso (tras empaquetar con esbuild): node labSim.cjs <variante> <nivelP1> <nivelP2> <partidas>
//   variante: base | apuestas | perdon | perdon+apuestas
//     base      reglas actuales; los bots no piden Square Karma
//     apuestas  cada bot pide Square Karma 666 siempre que puede (el rival acepta)
//     perdon    la PRIMERA captura de cada Avatar no le quita el loto
// Imprime una línea JSON por partida.

import { reducer } from "../../src/game/state/reducer";
import { initialState } from "../../src/game/state/state";
import { chooseBotMove, applyBotAction, getBotActions, type BotLevel } from "../../src/game/bot/buddhaBot";
import { realmFromPos } from "../../src/UI/realm";
import { REALM_PIECE_ORDER, type GameState, type PlayerId, type RealmPieceKind } from "../../src/game/types";

const [variant = "base", l1 = "normal", l2 = "normal", nStr = "10"] = process.argv.slice(2);
const bets = variant.includes("apuestas");
const forgive = variant.includes("perdon");
const MAX_TURNS = 3000;
console.log = () => {};
console.warn = () => {};
console.info = () => {};

const PLAYERS: PlayerId[] = ["P1", "P2"];
const act = (s: GameState, a: object) => reducer(s, a as never);

function bloomedInHumans(s: GameState, p: PlayerId): number {
  return REALM_PIECE_ORDER.filter((k) => {
    const a = s.realmPieces[p]?.[k];
    return a && a.unlocked && !a.inLimbo && realmFromPos(a.pos) === "HUMAN" && s.consolidatedAvatars[p]?.[k];
  }).length;
}
function inHumans(s: GameState, p: PlayerId): number {
  return REALM_PIECE_ORDER.filter((k) => {
    const a = s.realmPieces[p]?.[k];
    return a && a.unlocked && !a.inLimbo && realmFromPos(a.pos) === "HUMAN";
  }).length;
}
const blooms = (s: GameState, p: PlayerId) => Object.values(s.consolidatedAvatars[p] ?? {}).filter(Boolean).length;

function playOne() {
  let s = { ...initialState, gameStartedAt: 1, gameId: "lab" } as GameState;
  s = act(s, { type: "SET_TUTORIAL_MODE", on: true });
  s = act(s, { type: "SET_GENESIS_UI_COMPLETE" });
  const levels: Record<PlayerId, BotLevel> = { P1: l1 as BotLevel, P2: l2 as BotLevel };
  const captureCount: Record<string, number> = {};
  const m = {
    turns: 0, winner: null as PlayerId | null,
    avatarCaptures: 0, venomCaptures: 0, passes: 0,
    d777Opportunities: 0, d777Used: 0,
    betsRequested: 0, betsWon: 0,
    allAvatarsAt: -1, // turno en que ambos tienen a Whitman
    firstK: { 1: -1, 2: -1, 3: -1, 4: -1, 5: -1, 6: -1 } as Record<number, number>,
    longestQuiet: 0, // racha más larga de turnos sin ningún "momento"
    quietTurns: 0, // turnos sin ningún "momento"
  };
  let quiet = 0;
  let turn = 0;
  while (!s.winner && turn < MAX_TURNS) {
    const p = s.turn;
    const opp: PlayerId = p === "P1" ? "P2" : "P1";
    const before = s;

    // Respuestas pendientes (el rival siempre acepta).
    if (s.pendingSnakeBet && s.pendingSnakeBet.byPlayer !== p) s = act(s, { type: "ACCEPT_SNAKE_BET" });
    if (s.pendingTrade && s.pendingTrade.fromPlayer !== p) s = act(s, { type: "REFUSE_TRADE_OFFER" });

    // Pedir apuesta si se puede.
    if (bets && !s.pendingSnakeBet && !s.snakeBet) {
      for (const k of REALM_PIECE_ORDER) {
        const t = act(s, { type: "REQUEST_SNAKE_BET", player: p, targetAvatar: k });
        if (t !== s && t.pendingSnakeBet) { s = t; m.betsRequested++; break; }
      }
    }

    s = act({ ...s, phase: "idle", rollOptions: null } as GameState, { type: "ROLL" });
    const actions = getBotActions(s, p);
    if (actions.some((a) => a.kind === "dharma777")) m.d777Opportunities++;
    const choice = chooseBotMove(s, p, levels[p]);
    if (!choice) { s = act(s, { type: "PASS_NO_MOVES", player: p }); m.passes++; }
    else {
      if (choice.action.kind === "dharma777") m.d777Used++;
      const hadBet = !!s.snakeBet && s.snakeBet.byPlayer === p;
      const bloomsBefore = blooms(s, p);
      s = applyBotAction(s, p, choice.action);
      if (hadBet && !s.snakeBet && blooms(s, p) > bloomsBefore) m.betsWon++;
    }

    // Capturas y variante "perdón".
    let moment = false;
    for (const pl of PLAYERS) {
      for (const k of REALM_PIECE_ORDER) {
        const a0 = before.realmPieces[pl]?.[k];
        const a1 = s.realmPieces[pl]?.[k];
        if (!a1 || !a1.unlocked) continue;
        if ((!a0 || !a0.unlocked)) moment = true; // nace un Avatar
        if (a0 && a0.unlocked && !a0.inLimbo && a1.inLimbo) {
          m.avatarCaptures++; moment = true;
          const key = pl + k;
          captureCount[key] = (captureCount[key] ?? 0) + 1;
          if (forgive && captureCount[key] === 1) {
            s = { ...s, realmPieces: { ...s.realmPieces, [pl]: { ...s.realmPieces[pl], [k]: { ...a1, everCaptured: false } } } } as GameState;
          }
        }
      }
      for (const v of ["pig", "snake", "rooster"] as const) {
        if (!before.pieces[pl][v].inLimbo && s.pieces[pl][v].inLimbo) m.venomCaptures++;
      }
      if (blooms(s, pl) > blooms(before, pl)) moment = true;
      if (inHumans(s, pl) > inHumans(before, pl)) moment = true;
    }
    void opp;
    if (moment) quiet = 0; else { quiet++; m.quietTurns++; m.longestQuiet = Math.max(m.longestQuiet, quiet); }

    for (const pl of PLAYERS) {
      const b = bloomedInHumans(s, pl);
      for (let k = 1; k <= 6; k++) if (b >= k && m.firstK[k] < 0) m.firstK[k] = turn + 1;
    }
    if (m.allAvatarsAt < 0 && s.realmProgress.P1.currentRealmStep >= 6 && s.realmProgress.P2.currentRealmStep >= 6) m.allAvatarsAt = turn + 1;
    turn++;
    if (s.turn === p && !s.winner && !s.pendingSnakeBet) {
      // seguridad: si el turno no avanzó, forzar paso
      s = { ...s, turn: opp, phase: "idle", rollOptions: null } as GameState;
    }
  }
  m.turns = turn;
  m.winner = s.winner;
  return m;
}

const n = Number(nStr);
for (let i = 0; i < n; i++) {
  const r = playOne();
  process.stdout.write(JSON.stringify({ variant, l1, l2, ...r }) + "\n");
}
