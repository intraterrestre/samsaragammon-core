import { REALM_CANON } from "./realm/realmCanon";
import { karmaOracle } from "./Karma/KarmaOracle";
import { masterOracleLine } from "./master/masterEngine";
import { getMirrorPatternReading } from "./Karma/getMirrorPatternReading";
import { getOracleReading } from "./Karma/getOracleReading";
import type { GameState, PlayerId } from "./types";

type DerivedState = {
  hasRolled: boolean;
  a: number | null;
  b: number | null;
  sum: number | null;
  realmDataP1: any;
  realmDataP2: any;
  activeRealmData: any;
  activeEra: string;
  cyclesDone: number;
  cyclesNeeded: number;
  transitions: number;
  oracleText: string;
  mirrorData: {
    title: string;
    body: string;
    tags: string[];
  };
};

export function getGameDerivedState(params: {
  state: GameState;
  selectedPos: (player: PlayerId) => number;
}): DerivedState {
  const { state, selectedPos } = params;

  const hasRolled = state.phase === "rolled";
  const a = state.rollOptions?.[0] ?? null;
  const b = state.rollOptions?.[1] ?? null;
  const sum = a == null || b == null ? null : a + b;

  const realmIndexFromPos = (pos: number) => {
    return Math.max(0, Math.min(Math.floor(pos / 4), REALM_CANON.length - 1));
  };

  const realmIndexP1 = realmIndexFromPos(selectedPos("P1"));
  const realmIndexP2 = realmIndexFromPos(selectedPos("P2"));

  const realmDataP1 = REALM_CANON[realmIndexP1];
  const realmDataP2 = REALM_CANON[realmIndexP2];

  const activeRealmData = state.turn === "P1" ? realmDataP1 : realmDataP2;
  const activeEra = activeRealmData?.era ?? "Unknown";
  const activePlayer = state.turn;

  const activeProgress = state.realmProgress[activePlayer];
  const cyclesDone = activeProgress.completedLoopsInRealm;

  const loopsRequiredForRealmStep = (step: number) => {
    if (step >= 7) return 0;
    return step * 7;
  };

  const cyclesNeeded = loopsRequiredForRealmStep(
    activeProgress.currentRealmStep
  );
  const transitions = activeProgress.realmTransitions;

  const activePatternRaw =
    state.turn === "P1"
      ? (state.pattern as any)?.players?.P1?.label ??
        (state.pattern as any)?.P1?.label ??
        "UNKNOWN"
      : (state.pattern as any)?.players?.P2?.label ??
        (state.pattern as any)?.P2?.label ??
        "UNKNOWN";

  const activeChoice = state.lastMove?.choice ?? null;

  const oracleReading = karmaOracle({
    pattern: activePatternRaw,
    realm: activeRealmData?.id ?? "UNKNOWN",
    didCapture: state.lastMove?.didCapture ?? false,
    choice: activeChoice,
  });

  const fallbackOracleText = masterOracleLine(oracleReading, state.level);

  const mirrorData = getMirrorPatternReading({
    pattern: state.lastKarma?.pattern ?? 0,
    decisionSignature: state.decisionSignature[state.turn],
  });

  // Fase 2B — Buda Azul (7 septiembre 2026): el Oracle global ahora pasa
  // por la función canónica getOracleReading (misma que usa el Oracle
  // personal del Buda en GameShell.tsx) en vez de llamar a
  // getMasterMessage inline acá. Resultado observable sin cambios: es
  // exactamente la misma llamada, solo encapsulada.
  const oracleText = getOracleReading(state.lastMove, state.lastKarma) ?? fallbackOracleText;

  return {
    hasRolled,
    a,
    b,
    sum,
    realmDataP1,
    realmDataP2,
    activeRealmData,
    activeEra,
    cyclesDone,
    cyclesNeeded,
    transitions,
    oracleText,
    mirrorData,
  };
}